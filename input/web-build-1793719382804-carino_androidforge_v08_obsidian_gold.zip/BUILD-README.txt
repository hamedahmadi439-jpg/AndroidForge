CARINO Android project - version 0.8.0 (versionCode 8)

Changes in this update:
- Complete visual redesign to a premium obsidian-black / metallic-gold theme with restrained electric-blue GPS accents. This replaces the previous blue/neon appearance.
- Merged the guide, app introduction and creator information into one bottom-navigation destination: «راهنما و درباره کارینو». Creator is shown as «حامد».
- Shows the current Jalali date in the top-left header instead of «امروز».
- GPS display now uses continuous high-accuracy watchPosition updates while the GPS view is active.
- Trip mileage is added to the specific vehicle selected when the trip started, rather than writing to a legacy single-vehicle record.
- Switching the default vehicle refreshes its model, photo, odometer, status and related dashboard details.
- Preserves the existing Jalali calendar, multi-vehicle management, vehicle/document image handling and existing records.

Build: import this source project into AndroidForge and run the Android APK build workflow. This ZIP is source code, not an APK. JavaScript syntax was checked locally; an Android Gradle build and physical-device runtime test have not been performed.
