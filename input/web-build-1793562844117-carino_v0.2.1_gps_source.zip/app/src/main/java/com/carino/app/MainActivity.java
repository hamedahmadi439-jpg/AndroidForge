package com.carino.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.view.View;
import android.webkit.PermissionRequest;
import android.util.Log;

public class MainActivity extends Activity implements LocationListener {
    private static final int LOCATION_REQUEST = 410;
    private WebView webView;
    private LocationManager locationManager;
    private boolean tracking = false;
    private boolean waitingForStart = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(8, 14, 26));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(8, 14, 26));
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.addJavascriptInterface(new GpsBridge(), "CarinoGPS");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) { request.deny(); }
        });
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
               checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void beginLocationUpdates() {
        if (!hasLocationPermission()) return;
        try {
            tracking = true;
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED && locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3000L, 3f, this);
                Location last = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (last != null) sendLocation(last);
            } else {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000L, 5f, this);
            }
            js("window.onCarinoGpsStatus && window.onCarinoGpsStatus(true, 'ردیابی فعال است؛ برای دقت بهتر GPS گوشی را روشن کن.');");
        } catch (SecurityException e) { js("window.onCarinoGpsStatus && window.onCarinoGpsStatus(false, 'دسترسی موقعیت مکانی داده نشد.');"); }
    }

    private void sendLocation(Location l) {
        String script = "window.onCarinoLocation && window.onCarinoLocation(" + l.getLatitude() + "," + l.getLongitude() + "," + l.getAccuracy() + "," + l.getTime() + ");";
        js(script);
    }
    private void js(String script) { runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(script, null); }); }

    @Override public void onLocationChanged(Location location) { if (tracking) sendLocation(location); }
    @Override public void onProviderDisabled(String provider) { js("window.onCarinoGpsStatus && window.onCarinoGpsStatus(false, 'GPS خاموش شده است؛ آن را روشن کن.');"); }
    @Override public void onProviderEnabled(String provider) { }
    @Override public void onStatusChanged(String provider, int status, Bundle extras) { }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_REQUEST && waitingForStart) {
            waitingForStart = false;
            if (hasLocationPermission()) beginLocationUpdates();
            else js("window.onCarinoGpsStatus && window.onCarinoGpsStatus(false, 'برای ثبت مسیر باید مجوز مکان‌یابی را فعال کنی.');");
        }
    }

    private class GpsBridge {
        @JavascriptInterface public void startTracking() {
            runOnUiThread(() -> {
                if (hasLocationPermission()) beginLocationUpdates();
                else { waitingForStart = true; requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQUEST); }
            });
        }
        @JavascriptInterface public void stopTracking() {
            runOnUiThread(() -> { tracking = false; try { locationManager.removeUpdates(MainActivity.this); } catch (SecurityException ignored) {} });
        }
        @JavascriptInterface public boolean isNativeAvailable() { return true; }
    }

    @Override protected void onDestroy() {
        tracking = false;
        if (locationManager != null) { try { locationManager.removeUpdates(this); } catch (SecurityException ignored) {} }
        if (webView != null) { webView.removeJavascriptInterface("CarinoGPS"); webView.destroy(); }
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        new AlertDialog.Builder(this).setTitle("خروج از کارینو")
            .setMessage("آیا مطمئن هستید که می‌خواهید از برنامه خارج شوید؟")
            .setNegativeButton("ادامه کار", (dialog, which) -> dialog.dismiss())
            .setPositiveButton("خروج", (dialog, which) -> finish()).show();
    }
}
