Carino Android wrapper source project — version 0.2.0

This is the Android source project, not a prebuilt APK. It wraps the Carino
Persian RTL interface in an Android WebView.

Version 0.2.0 changes:
- Added an offline Persian (Solar Hijri) calendar page showing reminders,
  maintenance records, and document expiry dates on their corresponding days.
- Dates continue to be stored in ISO Gregorian form for reliable device-side
  date handling, and are displayed in Persian calendar format.
- Added detail popups for reminders, maintenance records, and documents.
- Added an Android exit confirmation dialog.
- Clarified that maintenance costs are entered and displayed in toman.

Current limitations:
- Multi-vehicle profiles, GPS trip-distance tracking, and native scheduled
  notifications while the app is closed are not implemented yet.
- OBD-II/Bluetooth integration, backup/restore, and image/color vehicle
  personalization are not implemented yet.
- Data is stored locally in WebView storage on this device.

Open this folder as a Gradle Android project in Android Studio, or submit this
ZIP to a build service that accepts a Gradle Android project at the ZIP root.


نسخه 0.2.1 - افزودن ردیابی سفر با GPS
- مجوزهای مکان‌یابی دقیق/تقریبی اندروید اضافه شد.
- صفحه ثبت مسیر، شروع/پایان سفر، محاسبه تقریبی مسافت، مدت سفر و تاریخچه محلی اضافه شد.
- امکان افزودن مسافت ذخیره‌شده به کیلومترشمار فقط پس از تأیید کاربر اضافه شد.
- محدودیت مهم: در این نسخه ردیابی فقط تا زمانی فعال است که برنامه باز و در پیش‌زمینه باشد؛ با بستن برنامه یا خاموش‌شدن صفحه ممکن است متوقف شود. سرویس پایدار پس‌زمینه در نسخه بعدی نیازمند پیاده‌سازی جداگانه است.
- دقت مسافت به کیفیت GPS، فضای باز، مجوز موقعیت و مدل گوشی وابسته است؛ مسافت GPS تخمینی است و باید با کیلومترشمار خودرو مقایسه شود.
