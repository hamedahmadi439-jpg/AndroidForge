IRAN MAN - AndroidForge Gradle project

این بسته یک پروژه واقعی Android Gradle است و بازی را در WebView داخلی اندروید اجرا می‌کند.

ساخت در AndroidForge:
1) محتویات ZIP را در ریشه مخزن یا پوشه‌ای که workflow به عنوان پروژه Gradle می‌سازد قرار دهید.
2) مسیر پروژه باید پوشه‌ای باشد که settings.gradle و build.gradle در آن قرار دارند.
3) دستور ساخت: gradle assembleDebug
4) خروجی معمول: app/build/outputs/apk/debug/app-debug.apk

ویژگی‌های نسخه آزمایشی: ۵۰ مرحله، ۵ فضای الهام‌گرفته از ایران، کنترل لمسی، پرش، حمله، سکه، دشمن، غول در هر ده مرحله و ذخیره محلی پیشرفت.

توجه: این نسخه Android/WebView است، نه خروجی Godot. قبل از انتشار نهایی باید روی دستگاه واقعی آزمایش و گرافیک/صدا/انیمیشن تکمیل شود.
