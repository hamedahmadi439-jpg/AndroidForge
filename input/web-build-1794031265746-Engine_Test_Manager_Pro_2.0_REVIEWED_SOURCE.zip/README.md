# Engine Test Manager Pro — reviewed source package

این بسته بر پایه سورس Flutter واقعیِ موجود در فایل `engine_test_manager_source_fixed.zip` بازبینی شده است؛ سورس کوتاه‌شده‌ای که در بسته قبلی ارسال شده بود، جایگزین آن نیست.

## ساختار
- `input/engine_test_manager/`: پروژه Flutter دسکتاپ
- `.github/workflows/build-desktop.yml`: ساخت خروجی Windows با GitHub Actions

## ساخت در GitHub با گوشی
1. یک Repository جدید در GitHub بسازید.
2. تمام محتویات این ZIP را در ریشه Repository بارگذاری کنید؛ پوشه `.github` باید در ریشه باشد.
3. وارد تب Actions شوید.
4. گردش کار `Build Engine Test Manager Pro (Windows)` را انتخاب و `Run workflow` را اجرا کنید.
5. پس از موفقیت، فایل ZIP را از بخش Artifacts همان اجرای Workflow دریافت کنید.

## وضعیت قابلیت‌ها
این بسته سورس پایه موجود را حفظ می‌کند و Workflow ساخت ویندوز را ساده و مستقل کرده است. این کار به‌تنهایی به معنی تکمیل امکانات برنامه‌ریزی‌شده مانند فرم شیفت ۸۰ موتوره، مدیریت کاربران، گزارش PDF/Excel، پنجره شناور یا System Tray نیست؛ این قابلیت‌ها باید جداگانه پیاده‌سازی و آزمایش شوند.

برنامه برای ثبت سوابق است و اتصال مستقیم به استند تست موتور در این نسخه وجود ندارد.
