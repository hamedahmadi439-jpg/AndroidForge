CARINO Android project - version 0.7.0 (versionCode 7)

Changes in this update:
- Renamed the main bottom tab to «خودروی من» and made it the primary dashboard.
- Added default-vehicle selection directly on the main «خودروی من» screen.
- Moved the Jalali date to the top-right header.
- Combined odometer/trip controls and GPS status/action into one shared dashboard card.
- Removed the quick-access grid and the smart-tools section.
- Added dedicated «راهنما» and «سازنده» tabs; creator is listed as «حامد».
- Added a «درباره ما» page reachable from the creator section.
- Applied a premium dark graphite/navy and champagne-gold visual theme.
- Kept existing multi-vehicle storage, Jalali calendar picker, vehicle photo picker, reminders, maintenance and documents logic.
- Vehicle display now uses the user's selected photo when available and a neutral generic fallback otherwise; model-specific licensed photo assets are not bundled.

Build: import this source project into AndroidForge and run its Android APK build workflow. This ZIP is source code, not an APK; it has not yet been built or runtime-tested on a physical Android device.
