package com.carino.app;
import android.content.*;
public class TripActionReceiver extends BroadcastReceiver { @Override public void onReceive(Context c,Intent i){Intent s=new Intent(c,TripService.class).setAction(i.getAction());if(android.os.Build.VERSION.SDK_INT>=26)c.startForegroundService(s);else c.startService(s);} }
