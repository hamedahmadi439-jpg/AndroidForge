package com.carino.app;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) { show(context, intent.getStringExtra("title"), intent.getStringExtra("body")); }
    public static void show(Context context, String title, String body) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel("carino_reminders") == null) nm.createNotificationChannel(new NotificationChannel("carino_reminders", "یادآوری‌های کارینو", NotificationManager.IMPORTANCE_DEFAULT));
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(context, "carino_reminders") : new Notification.Builder(context);
        b.setSmallIcon(com.carino.app.R.mipmap.ic_launcher).setContentTitle(title == null ? "یادآوری کارینو" : title).setContentText(body == null ? "موعد یادآوری شما رسیده است." : body).setAutoCancel(true);
        nm.notify((int)System.currentTimeMillis(), b.build());
    }
}
