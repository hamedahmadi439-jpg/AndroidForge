CARINO Premium AndroidForge source - functional revision

This package is based on the same black-and-gold HTML dashboard preview requested by the user.
Changes in this revision:
- Dashboard tiles and bottom navigation open working section dialogs.
- Car, service, reminder, document, parts, and guide forms accept entries.
- Entries are persisted locally in WebView localStorage and can be deleted.
- GPS uses watchPosition for continuous updates (not a one-shot location request); the button toggles tracking on/off and shows accuracy and speed.
- Header settings and notification shortcuts are wired; Persian date remains visible in the left side of the header.
- No trip or expense section is added.

Important GPS notes:
- Android location permission must be granted and device Location/GPS must be enabled.
- Accurate speed may be unavailable while stationary or when the device cannot calculate it.
- WebView geolocation behavior and AndroidForge build success still require testing on the target phone. This is source code, not a prebuilt APK.

Main UI: app/src/main/assets/index.html
Android entry point: app/src/main/java/com/carino/app/MainActivity.java
Package id: com.carino.app
