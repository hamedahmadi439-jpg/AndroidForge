Carino Android wrapper source project

This project wraps the supplied Carino PWA interface in an Android WebView.
Open this folder as a Gradle Android project in Android Studio, or submit this ZIP
to a build service that accepts a Gradle Android project at the ZIP root.

Important: this is source code, not a prebuilt APK. The current Carino interface
stores entries in the WebView browser storage on this device. Notifications,
scheduled reminders, cloud sync, backup, and OBD-II features are not implemented.
