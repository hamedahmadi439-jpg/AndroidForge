CARINO ANDROIDFORGE SOURCE - VERSION 0.9.1

Changes in this build:
- Replaced the stacked legacy blue/neon CSS themes with one final Obsidian Black + Metallic Gold visual system. The only cool accent retained is the restrained live-GPS status color.
- Reworked cards, buttons, form controls, vehicle image frame, tabs, modal and trip controls to match the new luxury layout.
- Vehicle records remain stored in the shared garage by unique vehicle ID; selecting a vehicle refreshes its odometer, details and model artwork from that vehicle record.
- Trip start pins the trip to the selected vehicle ID. On trip completion, measured distance is added to that pinned vehicle, even if the selected default vehicle changed during the trip.
- A new trip resets the previous native trip meter and stale last-trip value; reading the completed trip distance consumes it once to prevent accidental double addition.
- Persian date, live GPS/speed, help/creator area, reminders, documents, maintenance, and user-uploaded vehicle images are retained.

Vehicle illustrations are model-family vector illustrations (not manufacturer photographs). User-uploaded photos continue to take precedence.

Build this ZIP in AndroidForge with Target platform Android (APK). The source has not been built into an APK in this environment; install/update compatibility and on-device GPS behavior must be verified after AndroidForge build.
