import 'package:flutter/material.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:path/path.dart' as p;
import 'package:intl/intl.dart';
import 'dart:io';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  }
  await EngineDatabase.instance.init();
  runApp(const EngineTestManagerApp());
}

const navy = Color(0xFF101A2B);
const panel = Color(0xFF18263A);
const panel2 = Color(0xFF20324A);
const teal = Color(0xFF21C7B7);
const amber = Color(0xFFFFB547);
const muted = Color(0xFF9AABC0);

class EngineTestManagerApp extends StatelessWidget {
  const EngineTestManagerApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Engine Test Manager',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: navy,
        colorScheme: const ColorScheme.dark(
          primary: teal, secondary: amber, surface: panel,
        ),
        fontFamily: 'Segoe UI',
        useMaterial3: true,
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: panel2,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
        ),
      ),
      builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child!),
      home: const DashboardPage(),
    );
  }
}

class EngineRecord {
  final int? id;
  final String engineNo, result, errors, operatorName, notes, createdAt;
  const EngineRecord({this.id, required this.engineNo, required this.result,
    required this.errors, required this.operatorName, required this.notes, required this.createdAt});
  Map<String, Object?> toMap() => {
    'engine_no': engineNo, 'result': result, 'errors': errors,
    'operator_name': operatorName, 'notes': notes, 'created_at': createdAt,
  };
  factory EngineRecord.fromMap(Map<String, Object?> m) => EngineRecord(
    id: m['id'] as int, engineNo: m['engine_no'] as String,
    result: m['result'] as String, errors: m['errors'] as String,
    operatorName: m['operator_name'] as String, notes: m['notes'] as String,
    createdAt: m['created_at'] as String,
  );
}

class EngineDatabase {
  EngineDatabase._();
  static final instance = EngineDatabase._();
  Database? _db;
  Future<void> init() async {
    final dir = Directory('${Platform.environment['APPDATA'] ?? Directory.current.path}\\EngineTestManager');
    if (!await dir.exists()) await dir.create(recursive: true);
    _db = await databaseFactory.openDatabase(p.join(dir.path, 'engine_records.db'),
      options: OpenDatabaseOptions(version: 1, onCreate: (db, version) async {
        await db.execute('''CREATE TABLE engines (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          engine_no TEXT NOT NULL, result TEXT NOT NULL, errors TEXT NOT NULL,
          operator_name TEXT NOT NULL, notes TEXT NOT NULL, created_at TEXT NOT NULL
        )''');
      }));
  }
  Future<List<EngineRecord>> all() async {
    final rows = await _db!.query('engines', orderBy: 'id DESC');
    return rows.map(EngineRecord.fromMap).toList();
  }
  Future<void> save(EngineRecord r) async {
    if (r.id == null) {
      await _db!.insert('engines', r.toMap());
    } else {
      await _db!.update('engines', r.toMap(), where: 'id=?', whereArgs: [r.id]);
    }
  }
  Future<void> remove(int id) async => _db!.delete('engines', where: 'id=?', whereArgs: [id]);
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  List<EngineRecord> records = [];
  String filter = '';
  String active = 'همه موتورها';
  final search = TextEditingController();

  @override
  void initState() { super.initState(); refresh(); }
  Future<void> refresh() async {
    final data = await EngineDatabase.instance.all();
    if (mounted) setState(() => records = data);
  }
  List<EngineRecord> get visible => records.where((r) {
    final match = r.engineNo.toLowerCase().contains(filter.toLowerCase());
    if (!match) return false;
    if (active == 'سالم') return r.result == 'سالم';
    if (active == 'مردود') return r.result == 'مردود';
    if (active == 'نیازمند بررسی') return r.result == 'نیازمند بررسی';
    if (active == 'در انتظار') return r.result == 'در انتظار';
    return true;
  }).toList();

  @override
  Widget build(BuildContext context) {
    final ok = records.where((r) => r.result == 'سالم').length;
    final nok = records.where((r) => r.result == 'مردود').length;
    final review = records.where((r) => r.result == 'نیازمند بررسی').length;
    final pending = records.where((r) => r.result == 'در انتظار').length;
    return Scaffold(
      body: Row(children: [
        Container(width: 224, color: const Color(0xFF0C1422), padding: const EdgeInsets.all(20),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(width: 48, height: 48, decoration: BoxDecoration(color: teal.withOpacity(.15), borderRadius: BorderRadius.circular(15)),
              child: const Icon(Icons.precision_manufacturing, color: teal, size: 29)),
            const SizedBox(height: 16),
            const Text('ENGINE TEST', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
            const Text('MANAGER', style: TextStyle(color: teal, fontWeight: FontWeight.bold, letterSpacing: 3)),
            const SizedBox(height: 38),
            _sideItem(Icons.dashboard_rounded, 'داشبورد', true),
            _sideItem(Icons.view_list_rounded, 'سوابق موتورها', false),
            _sideItem(Icons.bar_chart_rounded, 'گزارش‌ها', false),
            _sideItem(Icons.settings_rounded, 'تنظیمات', false),
            const Spacer(),
            const Divider(color: panel2),
            const Row(children: [Icon(Icons.circle, color: teal, size: 9), SizedBox(width: 8), Text('ذخیره‌سازی محلی فعال', style: TextStyle(color: muted, fontSize: 11))]),
            const SizedBox(height: 8),
            const Text('نسخه اولیه 1.0', style: TextStyle(color: muted, fontSize: 11)),
          ])),
        Expanded(child: Padding(padding: const EdgeInsets.fromLTRB(28, 25, 28, 20),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('داشبورد مدیریت تست موتور', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800)),
                SizedBox(height: 5), Text('ثبت، پایش و پیگیری نتایج تست به‌صورت یکپارچه', style: TextStyle(color: muted)),
              ])),
              OutlinedButton.icon(onPressed: refresh, icon: const Icon(Icons.refresh), label: const Text('بروزرسانی')),
              const SizedBox(width: 10),
              FilledButton.icon(
                style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 17), backgroundColor: teal, foregroundColor: navy),
                onPressed: () => openForm(), icon: const Icon(Icons.add), label: const Text('ثبت موتور جدید', style: TextStyle(fontWeight: FontWeight.bold))),
            ]),
            const SizedBox(height: 25),
            Wrap(spacing: 14, runSpacing: 14, children: [
              _stat('کل رکوردها', records.length, Icons.dns_rounded, const Color(0xFF65A8FF)),
              _stat('سالم', ok, Icons.check_circle_outline, teal),
              _stat('مردود', nok, Icons.cancel_outlined, const Color(0xFFFF6877)),
              _stat('نیازمند بررسی', review, Icons.manage_search, amber),
              _stat('در انتظار نتیجه', pending, Icons.hourglass_empty, const Color(0xFFB7A2FF)),
            ]),
            const SizedBox(height: 26),
            Row(children: [
              const Text('سوابق تست موتور', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const Spacer(),
              SizedBox(width: 235, child: TextField(controller: search, onChanged: (v) => setState(() => filter = v),
                decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'جستجوی شماره موتور'))),
            ]),
            const SizedBox(height: 13),
            SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: [
              for (final f in ['همه موتورها','سالم','مردود','نیازمند بررسی','در انتظار'])
                Padding(padding: const EdgeInsets.only(left: 8), child: ChoiceChip(label: Text(f), selected: active == f,
                  selectedColor: teal.withOpacity(.22), onSelected: (_) => setState(() => active = f))),
            ])),
            const SizedBox(height: 12),
            Expanded(child: Container(decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(17), border: Border.all(color: panel2)),
              child: visible.isEmpty ? const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.inventory_2_outlined, size: 45, color: muted), SizedBox(height: 12),
                Text('هنوز رکوردی ثبت نشده است', style: TextStyle(color: muted)),
                SizedBox(height: 5), Text('برای شروع، روی «ثبت موتور جدید» بزنید', style: TextStyle(color: muted, fontSize: 12)),
              ])) : Column(children: [
                Container(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 15),
                  child: const Row(children: [
                    _head('ردیف', 55), _head('شماره موتور', 170), _head('نتیجه تست', 150),
                    _head('نوع خطا', 190), _head('اپراتور', 130), _head('تاریخ و ساعت', 170), _head('عملیات', 110),
                  ])),
                const Divider(height: 1, color: panel2),
                Expanded(child: ListView.separated(itemCount: visible.length, separatorBuilder: (_,__) => const Divider(height: 1, color: panel2),
                  itemBuilder: (context, i) {
                    final r = visible[i];
                    return Padding(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
                      child: Row(children: [
                        _cell('${r.id}', 55), _cell(r.engineNo, 170, bold: true),
                        SizedBox(width: 150, child: _badge(r.result)),
                        _cell(r.errors.isEmpty ? '—' : r.errors, 190),
                        _cell(r.operatorName, 130), _cell(r.createdAt, 170),
                        SizedBox(width: 110, child: Row(children: [
                          IconButton(tooltip: 'ویرایش', onPressed: () => openForm(record: r), icon: const Icon(Icons.edit_outlined, color: teal)),
                          IconButton(tooltip: 'حذف', onPressed: () => confirmDelete(r), icon: const Icon(Icons.delete_outline, color: Color(0xFFFF6877))),
                        ])),
                      ]));
                  })),
              ]))),
          ]))),
      ]),
    );
  }

  Widget _sideItem(IconData icon, String title, bool selected) => Container(
    margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 13),
    decoration: BoxDecoration(color: selected ? teal.withOpacity(.13) : Colors.transparent, borderRadius: BorderRadius.circular(11)),
    child: Row(children: [Icon(icon, color: selected ? teal : muted, size: 19), const SizedBox(width: 12),
      Text(title, style: TextStyle(color: selected ? Colors.white : muted, fontWeight: selected ? FontWeight.bold : FontWeight.normal))]));
  Widget _stat(String title, int value, IconData icon, Color color) => Container(
    width: 170, padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(15), border: Border.all(color: panel2)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Icon(icon, color: color, size: 19), const Spacer(), Text('$value', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800, color: color))]),
      const SizedBox(height: 9), Text(title, style: const TextStyle(color: muted, fontSize: 12)),
    ]));
  Future<void> openForm({EngineRecord? record}) async {
    final result = await showDialog<bool>(context: context, barrierDismissible: false,
      builder: (_) => RecordDialog(record: record));
    if (result == true) await refresh();
  }
  Future<void> confirmDelete(EngineRecord r) async {
    final yes = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('حذف رکورد'), content: Text('رکورد موتور ${r.engineNo} حذف شود؟'),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('انصراف')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حذف'))]));
    if (yes == true) { await EngineDatabase.instance.remove(r.id!); await refresh(); }
  }
}

class _head extends StatelessWidget {
  final String t; final double w; const _head(this.t, this.w);
  @override Widget build(BuildContext context) => SizedBox(width: w, child: Text(t, style: const TextStyle(color: muted, fontSize: 12, fontWeight: FontWeight.bold)));
}
Widget _cell(String t, double w, {bool bold = false}) => SizedBox(width: w, child: Text(t, maxLines: 1, overflow: TextOverflow.ellipsis,
  style: TextStyle(fontWeight: bold ? FontWeight.bold : FontWeight.normal)));
Widget _badge(String result) {
  final color = result == 'سالم' ? teal : result == 'مردود' ? const Color(0xFFFF6877) : result == 'در انتظار' ? const Color(0xFFB7A2FF) : amber;
  return Align(alignment: Alignment.centerLeft, child: Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    decoration: BoxDecoration(color: color.withOpacity(.13), borderRadius: BorderRadius.circular(20)),
    child: Text(result, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.bold))));
}

class RecordDialog extends StatefulWidget {
  final EngineRecord? record;
  const RecordDialog({super.key, this.record});
  @override State<RecordDialog> createState() => _RecordDialogState();
}
class _RecordDialogState extends State<RecordDialog> {
  final no = TextEditingController(), notes = TextEditingController();
  String result = 'در انتظار';
  final operator = TextEditingController(text: 'اپراتور');
  final options = ['سنسور','کویل','شمع','فشار روغن','سوخت‌رسانی','صدای غیرعادی','سایر'];
  final selected = <String>{};
  bool duplicate = false;
  List<EngineRecord> existing = [];
  @override void initState() {
    super.initState();
    final r = widget.record;
    if (r != null) {
      no.text = r.engineNo; notes.text = r.notes; result = r.result;
      operator.text = r.operatorName;
      selected.addAll(r.errors.isEmpty ? [] : r.errors.split('، '));
    }
    loadExisting();
  }
  Future<void> loadExisting() async { existing = await EngineDatabase.instance.all(); }
  Future<void> save() async {
    final engineNo = no.text.trim();
    if (engineNo.isEmpty) return;
    final dup = existing.any((r) => r.engineNo == engineNo && r.id != widget.record?.id);
    if (dup && !duplicate) {
      setState(() => duplicate = true);
      final proceed = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
        title: const Text('شماره موتور تکراری است'),
        content: const Text('این شماره قبلاً ثبت شده. آیا تست مجدد را ثبت می‌کنید؟'),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('بازگشت')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('ثبت تست مجدد'))]));
      if (proceed != true) { setState(() => duplicate = false); return; }
    }
    final stamp = widget.record?.createdAt ?? DateFormat('yyyy-MM-dd  HH:mm').format(DateTime.now());
    await EngineDatabase.instance.save(EngineRecord(id: widget.record?.id, engineNo: engineNo,
      result: result, errors: selected.join('، '), operatorName: operator.text.trim(),
      notes: notes.text.trim(), createdAt: stamp));
    if (mounted) Navigator.pop(context, true);
  }
  @override Widget build(BuildContext context) => AlertDialog(
    backgroundColor: panel, title: Row(children: [
      const Expanded(child: Text('ثبت اطلاعات موتور', style: TextStyle(fontWeight: FontWeight.bold))),
      IconButton(onPressed: () => Navigator.pop(context, false), icon: const Icon(Icons.close)),
    ]),
    content: SizedBox(width: 540, child: SingleChildScrollView(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('شماره موتور'), const SizedBox(height: 7),
      TextField(controller: no, autofocus: true, decoration: const InputDecoration(hintText: 'اسکن یا وارد کردن شماره موتور')),
      const SizedBox(height: 17), const Text('نتیجه تست'), const SizedBox(height: 7),
      Wrap(spacing: 8, children: ['در انتظار','سالم','مردود','نیازمند بررسی'].map((v) => ChoiceChip(
        label: Text(v), selected: result == v, onSelected: (_) => setState(() => result = v))).toList()),
      const SizedBox(height: 17), const Text('موارد خطا (امکان انتخاب چند مورد)'),
      const SizedBox(height: 7), Wrap(spacing: 8, runSpacing: 5, children: options.map((v) => FilterChip(
        label: Text(v), selected: selected.contains(v), onSelected: (yes) => setState(() {
          yes ? selected.add(v) : selected.remove(v);
        }))).toList()),
      const SizedBox(height: 17), const Text('نام اپراتور'), const SizedBox(height: 7),
      TextField(controller: operator, decoration: const InputDecoration(hintText: 'نام اپراتور')),
      const SizedBox(height: 17), const Text('توضیحات تکمیلی'), const SizedBox(height: 7),
      TextField(controller: notes, maxLines: 3, decoration: const InputDecoration(hintText: 'توضیحات اختیاری')),
    ]))),
    actions: [
      TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
      FilledButton(onPressed: save, style: FilledButton.styleFrom(backgroundColor: teal, foregroundColor: navy),
        child: const Text('ذخیره اطلاعات', style: TextStyle(fontWeight: FontWeight.bold))),
    ],
  );
}
