extends Node2D

const W := 960.0
const H := 540.0
const SAVE_PATH := "user://iran_man_save.cfg"
const GRAVITY := 1500.0
const SPEED := 300.0
const JUMP_V := -610.0

var state := "menu"
var stage := 1
var coins := 0
var score := 0
var lives := 3
var upgrade := 0
var player := Vector2(90, 350)
var velocity := Vector2.ZERO
var on_ground := false
var facing := 1
var camera_x := 0.0
var world_width := 2600.0
var platforms: Array[Rect2] = []
var coin_items: Array[Vector2] = []
var enemies: Array[Dictionary] = []
var projectiles: Array[Dictionary] = []
var decorations: Array[Dictionary] = []
var goal_x := 2480.0
var attack_cooldown := 0.0
var invincible := 0.0
var jump_queued := false
var touch_left := false
var touch_right := false
var touch_attack := false
var ui_layer: CanvasLayer
var hud_label: Label
var status_label: Label
var overlay: ColorRect
var overlay_title: Label
var overlay_sub: Label
var buttons: Dictionary = {}

func _ready() -> void:
	_build_ui()
	_load_save()
	set_process(true)
	set_physics_process(true)
	queue_redraw()

func _build_ui() -> void:
	ui_layer = CanvasLayer.new()
	add_child(ui_layer)
	hud_label = Label.new()
	hud_label.position = Vector2(18, 12)
	hud_label.add_theme_font_size_override("font_size", 22)
	hud_label.add_theme_color_override("font_color", Color.WHITE)
	hud_label.add_theme_color_override("font_shadow_color", Color.BLACK)
	hud_label.add_theme_constant_override("shadow_offset_x", 2)
	hud_label.add_theme_constant_override("shadow_offset_y", 2)
	ui_layer.add_child(hud_label)
	status_label = Label.new()
	status_label.position = Vector2(330, 12)
	status_label.size = Vector2(300, 32)
	status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	status_label.add_theme_font_size_override("font_size", 18)
	status_label.add_theme_color_override("font_color", Color.WHITE)
	ui_layer.add_child(status_label)
	_add_button("left", "◀", Vector2(24, 438), Vector2(76, 76), "move_left")
	_add_button("right", "▶", Vector2(108, 438), Vector2(76, 76), "move_right")
	_add_button("jump", "پرش", Vector2(790, 430), Vector2(78, 78), "jump")
	_add_button("attack", "قدرت", Vector2(875, 430), Vector2(70, 78), "attack")
	_add_button("pause", "Ⅱ", Vector2(890, 14), Vector2(52, 48), "pause")
	overlay = ColorRect.new()
	overlay.color = Color(0.015, 0.035, 0.07, 0.88)
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_layer.add_child(overlay)
	overlay_title = Label.new()
	overlay_title.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	overlay_title.position = Vector2(-300, 120)
	overlay_title.size = Vector2(600, 80)
	overlay_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	overlay_title.add_theme_font_size_override("font_size", 46)
	overlay_title.add_theme_color_override("font_color", Color(1, .82, .28))
	overlay.add_child(overlay_title)
	overlay_sub = Label.new()
	overlay_sub.position = Vector2(180, 220)
	overlay_sub.size = Vector2(600, 100)
	overlay_sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	overlay_sub.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	overlay_sub.add_theme_font_size_override("font_size", 22)
	overlay_sub.add_theme_color_override("font_color", Color.WHITE)
	overlay.add_child(overlay_sub)
	_add_overlay_button("start", "شروع بازی", Vector2(365, 350), Vector2(230, 62))
	_add_overlay_button("continue", "ادامه", Vector2(365, 350), Vector2(230, 62))
	_add_overlay_button("restart", "تلاش دوباره", Vector2(365, 350), Vector2(230, 62))
	_add_overlay_button("next", "مرحله بعد", Vector2(365, 350), Vector2(230, 62))
	_show_menu()

func _add_button(id: String, caption: String, pos: Vector2, size: Vector2, action: String) -> void:
	var b := Button.new()
	b.text = caption
	b.position = pos
	b.size = size
	b.add_theme_font_size_override("font_size", 24)
	b.modulate = Color(1, 1, 1, .82)
	ui_layer.add_child(b)
	buttons[id] = b
	if id == "left":
		b.button_down.connect(func(): touch_left = true)
		b.button_up.connect(func(): touch_left = false)
	elif id == "right":
		b.button_down.connect(func(): touch_right = true)
		b.button_up.connect(func(): touch_right = false)
	elif id == "jump":
		b.button_down.connect(func(): jump_queued = true)
	elif id == "attack":
		b.button_down.connect(func(): touch_attack = true)
		b.button_up.connect(func(): touch_attack = false)
	else:
		b.pressed.connect(_pause_game)

func _add_overlay_button(id: String, caption: String, pos: Vector2, size: Vector2) -> void:
	var b := Button.new()
	b.text = caption
	b.position = pos
	b.size = size
	b.add_theme_font_size_override("font_size", 24)
	b.pressed.connect(_overlay_action.bind(id))
	overlay.add_child(b)
	buttons[id] = b

func _show_menu() -> void:
	state = "menu"
	overlay.visible = true
	overlay_title.text = "IRAN MAN"
	overlay_sub.text = "ماجراجویی نصرت آغاز می‌شود!\n۵ دنیا • ۵۰ مرحله • ارتقاهای ویژه"
	_set_overlay_buttons(["start"])
	_update_hud()

func _overlay_action(id: String) -> void:
	match id:
		"start":
			stage = max(1, stage)
			lives = 3
			_start_stage()
		"continue":
			state = "playing"
			overlay.visible = false
		"restart":
			lives = 3
			_start_stage()
		"next":
			stage = min(50, stage + 1)
			_start_stage()

func _set_overlay_buttons(visible_ids: Array) -> void:
	for id in ["start", "continue", "restart", "next"]:
		buttons[id].visible = visible_ids.has(id)

func _start_stage() -> void:
	state = "playing"
	overlay.visible = false
	player = Vector2(80, 350)
	velocity = Vector2.ZERO
	camera_x = 0
	attack_cooldown = 0
	invincible = 1.2
	_generate_level()
	_update_hud()
	queue_redraw()

func _generate_level() -> void:
	platforms.clear()
	coin_items.clear()
	enemies.clear()
	projectiles.clear()
	decorations.clear()
	world_width = 2500.0 + float(stage % 5) * 180.0
	platforms.append(Rect2(0, 430, world_width, 110))
	var rng := RandomNumberGenerator.new()
	rng.seed = stage * 9817 + 77
	var x := 250.0
	while x < world_width - 260:
		var y := rng.randf_range(270, 390)
		var width := rng.randf_range(110, 210)
		platforms.append(Rect2(x, y, width, 22))
		for j in range(rng.randi_range(2, 4)):
			coin_items.append(Vector2(x + 24 + j * 30, y - 35))
		if rng.randf() < 0.78:
			enemies.append({"pos": Vector2(x + width + 35, 405), "dir": -1.0, "min": x + width - 25, "max": x + width + 100, "hp": 1 + int(stage / 15), "boss": false})
		x += rng.randf_range(250, 340)
	goal_x = world_width - 100
	for i in range(8):
		decorations.append({"x": rng.randf_range(0, world_width), "kind": rng.randi_range(0, 3), "scale": rng.randf_range(.7, 1.3)})
	if stage % 10 == 0:
		enemies.append({"pos": Vector2(world_width - 340, 365), "dir": -1.0, "min": world_width - 430, "max": world_width - 210, "hp": 8 + stage / 5, "boss": true})

func _physics_process(delta: float) -> void:
	if state != "playing":
		return
	attack_cooldown = max(0.0, attack_cooldown - delta)
	invincible = max(0.0, invincible - delta)
	var axis := Input.get_axis("move_left", "move_right")
	if touch_left or Input.is_action_pressed("move_left"):
		axis = -1
	if touch_right or Input.is_action_pressed("move_right"):
		axis = 1
	if axis != 0:
		facing = sign(axis)
	velocity.x = axis * SPEED * (1.0 + upgrade * .045)
	velocity.y += GRAVITY * delta
	if (Input.is_action_just_pressed("jump") or jump_queued) and on_ground:
		velocity.y = JUMP_V * (1.0 + upgrade * .025)
		on_ground = false
	jump_queued = false
	if Input.is_action_just_pressed("attack") or touch_attack:
		_fire()
	var old_y := player.y
	player += velocity * delta
	on_ground = false
	for p in platforms:
		if player.x + 17 > p.position.x and player.x - 17 < p.end.x and old_y + 22 <= p.position.y + 8 and player.y + 22 >= p.position.y and velocity.y >= 0:
			player.y = p.position.y - 22
			velocity.y = 0
			on_ground = true
	player.x = clamp(player.x, 20.0, world_width - 20)
	if player.y > H + 100:
		_lose_life()
	for c in coin_items.duplicate():
		if player.distance_to(c) < 34:
			coin_items.erase(c)
			coins += 1
			score += 100
			if coins >= 25 and upgrade < 4:
				upgrade = min(4, int(coins / 25))
	for e in enemies:
		e.pos.x += e.dir * (85.0 + stage * 2.0) * delta
		if e.pos.x < e.min or e.pos.x > e.max:
			e.dir *= -1
		if player.distance_to(e.pos) < (42 if e.boss else 30) and invincible <= 0:
			if velocity.y > 80 and player.y < e.pos.y - 12:
				e.hp -= 1
				velocity.y = -360
				if e.hp <= 0:
				score += 500 if e.boss else 200
			else:
				_lose_life()
	for shot in projectiles.duplicate():
		shot.pos.x += shot.dir * 650 * delta
		var remove := shot.pos.x < camera_x - 50 or shot.pos.x > camera_x + W + 50
		for e in enemies:
			if shot.pos.distance_to(e.pos) < (55 if e.boss else 30):
				e.hp -= 2 + upgrade
				remove = true
				if e.hp <= 0:
				score += 500 if e.boss else 200
				break
		if remove:
			projectiles.erase(shot)
	enemies = enemies.filter(func(e): return e.hp > 0)
	camera_x = clamp(player.x - W * .35, 0.0, world_width - W)
	if player.x >= goal_x:
		_complete_stage()
	_update_hud()
	queue_redraw()

func _fire() -> void:
	if attack_cooldown > 0:
		return
	attack_cooldown = max(.18, .55 - upgrade * .07)
	projectiles.append({"pos": player + Vector2(facing * 25, -5), "dir": facing})

func _lose_life() -> void:
	if invincible > 0:
		return
	lives -= 1
	invincible = 1.5
	if lives <= 0:
		state = "over"
		overlay.visible = true
		overlay_title.text = "پایان بازی"
		overlay_sub.text = "امتیاز: %d  |  مرحله: %d" % [score, stage]
		_set_overlay_buttons(["restart"])
	else:
		player = Vector2(max(60, camera_x + 70), 330)
		velocity = Vector2.ZERO
	_update_hud()

func _complete_stage() -> void:
	state = "clear"
	score += 1000 + stage * 50
	_save_progress()
	overlay.visible = true
	overlay_title.text = "مرحله با موفقیت تمام شد!"
	overlay_sub.text = "مرحله %d از ۵۰  |  امتیاز: %d" % [stage, score]
	if stage >= 50:
		overlay_title.text = "قهرمان ایران!"
		overlay_sub.text = "تو هر ۵۰ مرحله را فتح کردی!\nامتیاز نهایی: %d" % score
		_set_overlay_buttons(["restart"])
	else:
		_set_overlay_buttons(["next"])

func _pause_game() -> void:
	if state == "playing":
		state = "paused"
		overlay.visible = true
		overlay_title.text = "بازی متوقف شد"
		overlay_sub.text = "هر وقت آماده‌ای ادامه بده."
		_set_overlay_buttons(["continue", "restart"])

func _update_hud() -> void:
	hud_label.text = "❤️ %d     🪙 %d     امتیاز %d" % [lives, coins, score]
	status_label.text = "IRAN MAN  |  مرحله %d / ۵۰  |  زره %d" % [stage, upgrade]
	for id in ["left", "right", "jump", "attack", "pause"]:
		buttons[id].visible = state == "playing"

func _process(_delta: float) -> void:
	pass

func _draw() -> void:
	var region := Rect2(camera_x, 0, W, H)
	# Iranian landscape palette, without religious symbols.
	draw_rect(region, Color(0.42, 0.73, 0.91), true)
	for i in range(6):
		var bx := fposmod(i * 390.0 - camera_x * .22, W + 420) - 180
		_draw_mountain(Vector2(bx, 360), 190, 170, Color(.63, .76, .77))
		_draw_mountain(Vector2(bx + 110, 375), 230, 125, Color(.48, .67, .62))
	for d in decorations:
		var dx: float = d.x - camera_x
		if dx > -100 and dx < W + 100:
			if d.kind == 0:
				draw_rect(Rect2(dx, 350, 15, 80), Color(.43, .27, .15))
				draw_circle(Vector2(dx + 7, 340), 36 * d.scale, Color(.15, .48, .25))
			elif d.kind == 1:
				draw_rect(Rect2(dx, 370, 45, 60), Color(.77, .48, .28))
				draw_rect(Rect2(dx + 8, 390, 12, 40), Color(.28, .2, .15))
				draw_rect(Rect2(dx + 27, 385, 10, 12), Color(.3, .58, .72))
			elif d.kind == 2:
				draw_rect(Rect2(dx, 395, 70, 35), Color(.82, .7, .47))
				draw_rect(Rect2(dx + 12, 375, 46, 20), Color(.82, .7, .47))
			else:
				draw_rect(Rect2(dx, 380, 8, 50), Color(.35, .25, .17))
				draw_circle(Vector2(dx + 4, 375), 23, Color(.17, .43, .27))
	for p in platforms:
		var r := Rect2(p.position.x - camera_x, p.position.y, p.size.x, p.size.y)
		if r.end.x > -20 and r.position.x < W + 20:
			draw_rect(r, Color(.48, .29, .17))
			draw_rect(Rect2(r.position.x, r.position.y, r.size.x, 7), Color(.23, .61, .27))
			for xx in range(int(r.position.x), int(r.end.x), 32):
				draw_line(Vector2(xx, r.position.y + 8), Vector2(xx, r.position.y + 22), Color(.3, .2, .13), 2)
	for c in coin_items:
		draw_circle(Vector2(c.x - camera_x, c.y), 10, Color(1, .78, .12))
		draw_circle(Vector2(c.x - camera_x, c.y), 5, Color(1, .94, .5))
	for e in enemies:
		var ep: Vector2 = e.pos - Vector2(camera_x, 0)
		if e.boss:
			draw_rect(Rect2(ep.x - 28, ep.y - 45, 56, 65), Color(.43, .17, .18))
			draw_circle(ep + Vector2(0, -45), 27, Color(.65, .25, .19))
			draw_string(ThemeDB.fallback_font, ep + Vector2(-24, -52), "BOSS", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color.WHITE)
		else:
			draw_circle(ep, 19, Color(.68, .28, .2))
			draw_circle(ep + Vector2(-6, -4), 4, Color.WHITE)
			draw_circle(ep + Vector2(6, -4), 4, Color.WHITE)
	for s in projectiles:
		draw_circle(s.pos - Vector2(camera_x, 0), 9, Color(.25, .85, 1))
	_draw_player()
	# finish flag
	var gx := goal_x - camera_x
	if gx > -30 and gx < W + 30:
		draw_line(Vector2(gx, 300), Vector2(gx, 430), Color.WHITE, 5)
		draw_rect(Rect2(gx, 300, 55, 32), Color(.16, .55, .32))
	draw_rect(Rect2(camera_x, 430, W, 110), Color(.73, .58, .35))
	draw_rect(Rect2(camera_x, 430, W, 7), Color(.24, .56, .25))

func _draw_mountain(base: Vector2, width: float, height: float, color: Color) -> void:
	var pts := PackedVector2Array([Vector2(base.x - width/2, base.y), Vector2(base.x, base.y-height), Vector2(base.x+width/2, base.y)])
	for i in range(pts.size()):
		pts[i].x -= camera_x * .0
	draw_colored_polygon(pts, color)

func _draw_player() -> void:
	var p := player - Vector2(camera_x, 0)
	if invincible > 0 and int(Time.get_ticks_msec() / 100) % 2 == 0:
		return
	# Original boy outfit; upgrades add armor layers but retain the same hero.
	draw_rect(Rect2(p.x - 13, p.y - 2, 26, 23), Color(.19, .34, .76))
	draw_rect(Rect2(p.x - 16, p.y - 25, 32, 25), Color(.92, .88, .73))
	draw_rect(Rect2(p.x - 17, p.y - 29, 34, 8), Color(.72, .19, .15))
	draw_circle(p + Vector2(0, -39), 15, Color(.79, .52, .32))
	draw_rect(Rect2(p.x - 15, p.y - 55, 30, 8), Color(.72, .12, .13))
	draw_rect(Rect2(p.x - 14, p.y - 59, 28, 5), Color(.28, .16, .1))
	draw_circle(p + Vector2(5, -41), 2, Color(.08, .08, .08))
	draw_line(p + Vector2(15 * facing, -16), p + Vector2(26 * facing, -7), Color(.79, .52, .32), 6)
	if upgrade >= 1:
		draw_rect(Rect2(p.x - 18, p.y - 28, 36, 18), Color(.76, .2, .13))
	if upgrade >= 2:
		draw_rect(Rect2(p.x - 17, p.y - 30, 34, 28), Color(.82, .55, .16))
	if upgrade >= 3:
		draw_circle(p + Vector2(0, -40), 17, Color(.8, .25, .12))
		draw_rect(Rect2(p.x - 13, p.y - 44, 26, 8), Color(.18, .72, .92))
	if upgrade >= 4:
		draw_circle(p + Vector2(-18, -12), 7, Color(.2, .78, 1))
		draw_circle(p + Vector2(18, -12), 7, Color(.2, .78, 1))

func _save_progress() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("progress", "stage", stage)
	cfg.set_value("progress", "coins", coins)
	cfg.set_value("progress", "score", score)
	cfg.set_value("progress", "upgrade", upgrade)
	cfg.save(SAVE_PATH)

func _load_save() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) == OK:
		stage = int(cfg.get_value("progress", "stage", 1))
		coins = int(cfg.get_value("progress", "coins", 0))
		score = int(cfg.get_value("progress", "score", 0))
		upgrade = int(cfg.get_value("progress", "upgrade", 0))
