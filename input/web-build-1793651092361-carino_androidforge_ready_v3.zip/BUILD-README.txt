Carino Android wrapper source project - version 0.3.0

This is an updated Gradle Android project for AndroidForge / Android Studio.
Application ID remains com.carino.app and versionCode is 3.

Included in this update:
- refreshed dark sporty interface and revised welcome text
- Persian-calendar date display using the device Persian locale / Intl calendar
- GPS location request (requires location permission and device location enabled)
- native Android scheduled reminder notifications (requires notification permission)
- detail popups for saved reminders, maintenance and documents
- confirmation before exiting the app

Data is still stored locally in this WebView on this device. GPS is read only when the user taps the GPS control.
This ZIP is source code, not a prebuilt APK. Submit the ZIP to the same AndroidForge build workflow.
Important: installing over the existing APK requires the same signing key as the previous APK. If Android reports a signature conflict, do not uninstall the existing app until its data is backed up.
