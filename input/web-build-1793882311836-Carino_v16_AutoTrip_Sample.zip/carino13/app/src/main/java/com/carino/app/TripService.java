package com.carino.app;

import android.app.*;
import android.content.*;
import android.location.*;
import android.os.*;
import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import java.util.*;

public class TripService extends Service implements LocationListener {
  static final String START="com.carino.app.TRIP_START", PAUSE="com.carino.app.TRIP_PAUSE", STOP="com.carino.app.TRIP_STOP", AUTO_ON="com.carino.app.TRIP_AUTO_ON", AUTO_OFF="com.carino.app.TRIP_AUTO_OFF";
  private LocationManager lm; private Location last; private boolean paused=false, autoMode=false, autoTrip=false; private int movingSamples=0; private long stoppedSince=0; private double meters=0;
  private static final int N=7401;
  @Override public void onCreate(){super.onCreate();lm=(LocationManager)getSystemService(LOCATION_SERVICE);meters=getSharedPreferences("carino_trip",0).getFloat("meters",0);}
  @Override public int onStartCommand(Intent in,int flags,int id){String a=in==null?START:in.getAction();startForeground(N,notification("مدیریت سفر"));if(AUTO_OFF.equals(a)){autoMode=false;autoTrip=false;movingSamples=0;stoppedSince=0;try{lm.removeUpdates(this);}catch(Exception ignored){}stopForeground(true);stopSelf();return START_NOT_STICKY;}if(AUTO_ON.equals(a)){autoMode=true;paused=false;last=null;movingSamples=0;autoTrip=false;stoppedSince=0;meters=0;startForeground(N,notification("ثبت خودکار فعال است؛ منتظر حرکت خودرو"));requestGps();return START_STICKY;}if(STOP.equals(a)){finishTrip();return START_NOT_STICKY;}if(PAUSE.equals(a)){paused=true;last=null;notifyState("توقف موقت");return START_STICKY;}if(START.equals(a)){boolean resuming=paused;paused=false;last=null;if(!resuming){meters=0;getSharedPreferences("carino_trip",0).edit().putFloat("meters",0).putFloat("last_trip_km",0).apply();}startForeground(N,notification("در حال ثبت مسیر"));requestGps();}return START_STICKY;}
  private void requestGps(){if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED||checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED){try{lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,2500,0,this);}catch(Exception ignored){}}}
  private PendingIntent action(String act,int req){Intent i=new Intent(this,TripActionReceiver.class);i.setAction(act);return PendingIntent.getBroadcast(this,req,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
  private Notification notification(String state){Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"carino_trip"):new Notification.Builder(this);b.setSmallIcon(android.R.drawable.ic_menu_mylocation).setContentTitle("کارینو | ثبت مسافت").setContentText(state+" • "+String.format(Locale.US,"%.2f km",meters/1000)).setOngoing(true).addAction(new Notification.Action.Builder(android.R.drawable.ic_media_play,"شروع حرکت",action(START,1)).build()).addAction(new Notification.Action.Builder(android.R.drawable.ic_media_pause,"توقف موقت",action(PAUSE,2)).build()).addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,"پایان حرکت",action(STOP,3)).build());return b.build();}
  private void notifyState(String s){((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(N,notification(s));}
  @Override public void onLocationChanged(Location p){if(paused||p.getAccuracy()>25)return;float d=last==null?0:last.distanceTo(p);float speed=p.hasSpeed()?p.getSpeed():(last==null?0:d/Math.max(1,(p.getTime()-last.getTime())/1000f));if(autoMode){if(!autoTrip){if(speed>=2.5f){movingSamples++;}else movingSamples=0;if(movingSamples>=3){autoTrip=true;meters=0;stoppedSince=0;notifyState("حرکت خودرو تشخیص داده شد؛ ثبت خودکار سفر آغاز شد");}}else{if(speed>=1.5f&&d>=5&&d<=250){meters+=d;stoppedSince=0;}else if(speed<1.2f){if(stoppedSince==0)stoppedSince=System.currentTimeMillis();if(System.currentTimeMillis()-stoppedSince>=180000){saveAutoTrip();}}}last=p;getSharedPreferences("carino_trip",0).edit().putFloat("meters",(float)meters).apply();if(autoMode)notifyState(autoTrip?"در حال ثبت خودکار مسیر":"ثبت خودکار فعال؛ منتظر حرکت خودرو");return;}if(last!=null&&speed>=1.5f&&d>=5&&d<=250)meters+=d;last=p;getSharedPreferences("carino_trip",0).edit().putFloat("meters",(float)meters).apply();notifyState("در حال ثبت مسیر");}
  private void saveAutoTrip(){double km=meters/1000.0;if(km>=0.05)getSharedPreferences("carino_trip",0).edit().putFloat("last_trip_km",(float)km).apply();meters=0;autoTrip=false;movingSamples=0;stoppedSince=0;last=null;notifyState("سفر ثبت شد؛ آماده حرکت بعدی");}
  private void finishTrip(){try{lm.removeUpdates(this);}catch(Exception ignored){}getSharedPreferences("carino_trip",0).edit().putFloat("last_trip_km",(float)(meters/1000)).putFloat("meters",0).apply();meters=0;stopForeground(true);stopSelf();}
  @Override public void onProviderDisabled(String p){notifyState("GPS خاموش است");}@Override public void onProviderEnabled(String p){}@Override public void onStatusChanged(String p,int s,Bundle b){}
  @Override public IBinder onBind(Intent i){return null;}
}
