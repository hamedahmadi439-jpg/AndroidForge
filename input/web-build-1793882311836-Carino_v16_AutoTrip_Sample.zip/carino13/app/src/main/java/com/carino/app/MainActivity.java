package com.carino.app;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.view.View;
import android.app.AlertDialog;
import android.webkit.PermissionRequest;
import android.content.DialogInterface;
import android.app.PendingIntent;
import android.content.Intent;
import android.app.AlarmManager;
import android.net.Uri;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int FILE_CHOOSER_REQUEST = 77;
    private android.webkit.ValueCallback<Uri[]> filePathCallback;
    private static final int PERMISSION_REQUEST = 41;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(8,7,6));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(8,7,6));
        createChannel();
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, PERMISSION_REQUEST);
        else if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, PERMISSION_REQUEST);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true); settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true); settings.setAllowContentAccess(true); settings.setGeolocationEnabled(true);
        webView.addJavascriptInterface(new CarinoBridge(this), "CarinoNative");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, android.webkit.ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, FILE_CHOOSER_REQUEST); }
                catch (Exception e) { filePathCallback = null; return false; }
                return true;
            }
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                boolean granted = Build.VERSION.SDK_INT < 23 || (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED);
                callback.invoke(origin, granted, false);
            }
        });
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER); setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            filePathCallback.onReceiveValue(results); filePathCallback = null;
        }
    }
    private void createChannel() { if (Build.VERSION.SDK_INT >= 26) { NotificationChannel c = new NotificationChannel("carino_reminders", "یادآوری‌های کارینو", NotificationManager.IMPORTANCE_DEFAULT); c.setDescription("یادآوری سرویس و مدارک خودرو"); getSystemService(NotificationManager.class).createNotificationChannel(c); NotificationChannel t = new NotificationChannel("carino_trip", "ثبت مسیر کارینو", NotificationManager.IMPORTANCE_LOW); getSystemService(NotificationManager.class).createNotificationChannel(t); } }
    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else new AlertDialog.Builder(this).setMessage("از کارینو خارج می‌شوید؟").setNegativeButton("انصراف", null).setPositiveButton("خروج", (d,w)->finish()).show(); }

    public static class CarinoBridge {
        private final Context context;
        CarinoBridge(Context c) { context = c; }
        @JavascriptInterface public void scheduleNotification(String title, String body, long when) {
            Intent i = new Intent(context, ReminderReceiver.class); i.putExtra("title", title); i.putExtra("body", body);
            int id = (title + body + when).hashCode(); PendingIntent pi = PendingIntent.getBroadcast(context, id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am != null && when > System.currentTimeMillis()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        }
        @JavascriptInterface public void showNotification(String title, String body) { ReminderReceiver.show(context, title, body); }
        @JavascriptInterface public boolean hasLocationPermission(){ return context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED || context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED; }
        @JavascriptInterface public void enableAutoTrip(){ Intent i=new Intent(context,TripService.class).setAction(TripService.AUTO_ON); if(Build.VERSION.SDK_INT>=26)context.startForegroundService(i);else context.startService(i); }
        @JavascriptInterface public void disableAutoTrip(){ Intent i=new Intent(context,TripService.class).setAction(TripService.AUTO_OFF); if(Build.VERSION.SDK_INT>=26)context.startForegroundService(i);else context.startService(i); }
        @JavascriptInterface public void startTrip(){ Intent i=new Intent(context,TripService.class).setAction(TripService.START); if(Build.VERSION.SDK_INT>=26)context.startForegroundService(i);else context.startService(i); }
        @JavascriptInterface public void pauseTrip(){ Intent i=new Intent(context,TripService.class).setAction(TripService.PAUSE); if(Build.VERSION.SDK_INT>=26)context.startForegroundService(i);else context.startService(i); }
        @JavascriptInterface public void stopTrip(){ Intent i=new Intent(context,TripService.class).setAction(TripService.STOP); if(Build.VERSION.SDK_INT>=26)context.startForegroundService(i);else context.startService(i); }
        @JavascriptInterface public float lastTripKm(){ android.content.SharedPreferences p=context.getSharedPreferences("carino_trip",0); float km=p.getFloat("last_trip_km",0); p.edit().putFloat("last_trip_km",0).apply(); return km; }
    }
}
