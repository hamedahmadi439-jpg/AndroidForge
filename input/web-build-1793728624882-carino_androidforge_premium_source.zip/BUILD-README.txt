CARINO - AndroidForge project package

This package keeps the existing Android/Gradle wrapper from the tested Carino project structure and replaces only the WebView home interface with the premium black-and-gold HTML preview.

Main UI: app/src/main/assets/index.html
Android wrapper and native Java files are retained from carino_androidforge_v09_1_obsidian_gold_fix.zip.

Important: This is a source project package for AndroidForge, not a prebuilt APK. Build success and device behavior still need to be verified in AndroidForge. GPS access depends on Android permissions and WebView bridge/location configuration; this package does not claim that GPS has been runtime-tested.
