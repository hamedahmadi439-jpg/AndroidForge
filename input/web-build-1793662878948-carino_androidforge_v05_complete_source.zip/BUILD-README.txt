CARINO Android project - version 0.5.0 (versionCode 5)

Implemented in this source update:
- Manufacturer-dependent Iranian vehicle model list.
- Multiple vehicle profiles with separate reminders, maintenance records and documents per active vehicle.
- Persian-calendar date picker for reminders, maintenance and document expiry. Selected dates are stored as Gregorian ISO dates for reliable notifications and sorting.
- Android WebView image picker support for selecting personal vehicle/document photos.
- Dark automotive interface polish.

Image note: this build continues to support personal gallery photos. It does not yet contain a licensed photorealistic offline image library for every vehicle model; model-specific offline artwork is a future asset task and is not represented as real vehicle photography.

Build: import this project into Android Studio / AndroidForge and build the APK. This source ZIP has not itself been runtime-tested on a physical Android device.
