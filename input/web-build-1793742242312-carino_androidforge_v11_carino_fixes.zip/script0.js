
function updatePersianDate(){
 const now=new Date();
 const dateFmt=new Intl.DateTimeFormat('fa-IR-u-ca-persian-nu-latn',{year:'numeric',month:'long',day:'numeric'});
 const weekdayFmt=new Intl.DateTimeFormat('fa-IR',{weekday:'long'});
 const dateEl=document.getElementById('persianDate');
 const dayEl=document.getElementById('persianWeekday');
 if(dateEl) dateEl.textContent=dateFmt.format(now);
 if(dayEl) dayEl.textContent=weekdayFmt.format(now);
}
updatePersianDate();
setInterval(updatePersianDate,60000);
function toast(t){const e=document.getElementById('toast');e.textContent=t;e.style.opacity='1';e.style.transform='translate(-50%,0)';clearTimeout(window.tt);window.tt=setTimeout(()=>{e.style.opacity='0';e.style.transform='translate(-50%,15px)'},1800)}
let gpsWatchId=null;
function getLocation(){
 const s=document.getElementById('gpsStatus'),b=document.getElementById('gpsBtn');
 if(!navigator.geolocation){s.innerHTML='وضعیت: <em>مکان‌یابی در این محیط پشتیبانی نمی‌شود.</em>';return;}
 if(gpsWatchId!==null){navigator.geolocation.clearWatch(gpsWatchId);gpsWatchId=null;b.textContent='شروع GPS زنده ⌖';s.innerHTML='وضعیت: <em>ردیابی متوقف شد.</em>';return;}
 b.disabled=true;b.textContent='در حال اتصال…';s.innerHTML='وضعیت: <em>در انتظار مجوز و دریافت ماهواره…</em>';
 gpsWatchId=navigator.geolocation.watchPosition(p=>{
  const c=p.coords; s.innerHTML=`وضعیت: <em>ردیابی زنده فعال است · ${c.latitude.toFixed(5)} ، ${c.longitude.toFixed(5)}</em>`;
  document.getElementById('gpsAccuracy').textContent='دقت: '+Math.round(c.accuracy)+' متر';
  document.getElementById('gpsSpeed').textContent='سرعت: '+(c.speed==null?'—':(c.speed*3.6).toFixed(1)+' km/h');
  b.disabled=false;b.textContent='توقف GPS زنده';
  localStorage.setItem('carino_last_location',JSON.stringify({lat:c.latitude,lon:c.longitude,accuracy:c.accuracy,time:Date.now()}));
 },e=>{
  const m=e.code===1?'مجوز مکان‌یابی رد شد؛ دسترسی موقعیت را در تنظیمات اندروید فعال کنید.':e.code===2?'موقعیت در دسترس نیست؛ GPS گوشی را روشن کنید.':'زمان دریافت موقعیت تمام شد؛ در فضای باز دوباره تلاش کنید.';
  s.innerHTML='وضعیت: <em>'+m+'</em>';b.disabled=false;b.textContent='تلاش دوباره ⌖';
  if(gpsWatchId!==null){navigator.geolocation.clearWatch(gpsWatchId);gpsWatchId=null;}
 },{enableHighAccuracy:true,timeout:25000,maximumAge:1000});
}
const sectionInfo={
 car:['خودروی من','مشخصات خودروی فعال را ثبت و ویرایش کن.','مدل خودرو','پژو ۲۰۶','سال ساخت','۱۳۹۶','کیلومتر فعلی','۹۰۵۰۰'],
 service:['تعمیرات و سرویس','سوابق سرویس و تعمیرات خودرو را ثبت کن.','عنوان سرویس','تعویض روغن','تاریخ','۱۴۰۵/۰۸/۱۲','هزینه (تومان)','۰'],
 reminder:['یادآوری‌ها','یادآوری سرویس‌ها و مدارک را ثبت کن.','عنوان یادآوری','موعد تعویض روغن','تاریخ یادآوری','۱۴۰۵/۰۹/۰۱','توضیحات',''],
 docs:['مدارک خودرو','تاریخ اعتبار مدارک خودرو را نگهداری کن.','نوع مدرک','بیمه شخص ثالث','تاریخ انقضا','۱۴۰۵/۱۲/۲۹','شماره/توضیح',''],
 parts:['قطعات و تعویض‌ها','قطعات نصب‌شده و زمان تعویض بعدی را ثبت کن.','نام قطعه','لنت ترمز','تاریخ تعویض','۱۴۰۵/۰۸/۰۱','کیلومتر تعویض','۹۰۰۰۰'],
 guide:['عیب‌یابی و راهنما','نشانه‌های خرابی را ثبت کن و راهنمای بررسی اولیه بگیر.','علامت یا مشکل','صدای غیرعادی هنگام گاز دادن','توضیحات','']
};
function openSection(key){const d=sectionInfo[key];if(!d)return;let fields='';for(let i=2;i<d.length;i+=2){fields+=`<label class="form-label">${d[i]}</label><input class="form-input" id="f${i}" placeholder="${d[i+1]}" value="${d[i+1]}">`;}
 const records=JSON.parse(localStorage.getItem('carino_'+key)||'[]');
 document.getElementById('sectionTitle').textContent=d[0];document.getElementById('sectionDesc').textContent=d[1];document.getElementById('sectionFields').innerHTML=fields;
 document.getElementById('sectionRecords').innerHTML=records.length?records.map((r,i)=>`<div class="saved-row"><b>${escapeHtml(r.title||r.values[0]||'ثبت‌شده')}</b><small>${escapeHtml(r.summary||r.values.slice(1).join(' · '))}</small><button onclick="deleteRecord('${key}',${i})">حذف</button></div>`).join(''):'<p class="empty-record">هنوز موردی ثبت نشده است.</p>';
 document.getElementById('sectionSave').onclick=()=>saveSection(key,d);document.getElementById('sectionModal').style.display='grid';}
function saveSection(key,d){const values=[];for(let i=2;i<d.length;i+=2){values.push(document.getElementById('f'+i).value.trim());}if(!values.some(Boolean)){toast('حداقل یک مورد را وارد کن');return;}const arr=JSON.parse(localStorage.getItem('carino_'+key)||'[]');arr.unshift({title:values[0],summary:values.slice(1).filter(Boolean).join(' · '),values,time:Date.now()});localStorage.setItem('carino_'+key,JSON.stringify(arr));openSection(key);toast('اطلاعات ذخیره شد');}
function deleteRecord(key,i){const arr=JSON.parse(localStorage.getItem('carino_'+key)||'[]');arr.splice(i,1);localStorage.setItem('carino_'+key,JSON.stringify(arr));openSection(key);}
function escapeHtml(x){return String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function closeSection(){document.getElementById('sectionModal').style.display='none';}
function goHome(){closeSection();window.scrollTo({top:0,behavior:'smooth'});}
function openSettings(){document.getElementById('sectionSave').style.display='block';document.getElementById('sectionTitle').textContent='تنظیمات کارینو';document.getElementById('sectionDesc').textContent='تنظیمات برنامه روی همین گوشی نگهداری می‌شود.';document.getElementById('sectionFields').innerHTML='<label class="form-label">نام مالک خودرو</label><input class="form-input" id="ownerName" placeholder="نام شما"><label class="form-label">واحد مسافت</label><input class="form-input" value="کیلومتر" disabled>';document.getElementById('sectionRecords').innerHTML='<p class="empty-record">اطلاعات برنامه در حافظه همین دستگاه ذخیره می‌شود.</p>';document.getElementById('sectionSave').onclick=()=>{localStorage.setItem('carino_owner',document.getElementById('ownerName').value);toast('تنظیمات ذخیره شد');closeSection()};document.getElementById('sectionModal').style.display='grid';}

