package com.carino.app;

import android.app.*;
import android.content.*;
import android.location.*;
import android.os.*;
import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import java.util.*;

public class TripService extends Service implements LocationListener {
  static final String START="com.carino.app.TRIP_START", PAUSE="com.carino.app.TRIP_PAUSE", STOP="com.carino.app.TRIP_STOP";
  private LocationManager lm; private Location last; private boolean paused=false; private double meters=0;
  private static final int N=7401;
  @Override public void onCreate(){super.onCreate();lm=(LocationManager)getSystemService(LOCATION_SERVICE);meters=getSharedPreferences("carino_trip",0).getFloat("meters",0);}
  @Override public int onStartCommand(Intent in,int flags,int id){String a=in==null?START:in.getAction();startForeground(N,notification("مدیریت سفر"));if(STOP.equals(a)){finishTrip();return START_NOT_STICKY;}if(PAUSE.equals(a)){paused=true;last=null;notifyState("توقف موقت");return START_STICKY;}if(START.equals(a)){paused=false;last=null;meters=0;getSharedPreferences("carino_trip",0).edit().putFloat("meters",0).putFloat("last_trip_km",0).apply();startForeground(N,notification("در حال ثبت مسیر"));if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED||checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED){try{lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,2500,0,this);}catch(Exception ignored){}}}return START_STICKY;}
  private PendingIntent action(String act,int req){Intent i=new Intent(this,TripActionReceiver.class);i.setAction(act);return PendingIntent.getBroadcast(this,req,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
  private Notification notification(String state){Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"carino_trip"):new Notification.Builder(this);b.setSmallIcon(android.R.drawable.ic_menu_mylocation).setContentTitle("کارینو | ثبت مسافت").setContentText(state+" • "+String.format(Locale.US,"%.2f km",meters/1000)).setOngoing(true).addAction(new Notification.Action.Builder(android.R.drawable.ic_media_play,"شروع حرکت",action(START,1)).build()).addAction(new Notification.Action.Builder(android.R.drawable.ic_media_pause,"توقف موقت",action(PAUSE,2)).build()).addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,"پایان حرکت",action(STOP,3)).build());return b.build();}
  private void notifyState(String s){((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(N,notification(s));}
  @Override public void onLocationChanged(Location p){if(paused||p.getAccuracy()>25)return;if(last!=null){float d=last.distanceTo(p);float speed=p.hasSpeed()?p.getSpeed():d/Math.max(1,(p.getTime()-last.getTime())/1000f);if(speed>=1.5f && d>=5 && d<=250)meters+=d;}last=p;getSharedPreferences("carino_trip",0).edit().putFloat("meters",(float)meters).apply();notifyState("در حال ثبت مسیر");}
  private void finishTrip(){try{lm.removeUpdates(this);}catch(Exception ignored){}getSharedPreferences("carino_trip",0).edit().putFloat("last_trip_km",(float)(meters/1000)).putFloat("meters",0).apply();meters=0;stopForeground(true);stopSelf();}
  @Override public void onProviderDisabled(String p){notifyState("GPS خاموش است");}@Override public void onProviderEnabled(String p){}@Override public void onStatusChanged(String p,int s,Bundle b){}
  @Override public IBinder onBind(Intent i){return null;}
}
