CARINO ANDROIDFORGE SOURCE - VERSION 0.4.0

Upload this ZIP to AndroidForge as the project source and build the Android APK.
Application ID remains: com.carino.app
Version code: 4
Version name: 0.4.0

Included updates:
- Refreshed dark sporty blue interface and larger typography.
- Removed the beta-version label.
- Editable reminder items and editable upcoming reminders.
- Vehicle photo and color fields; document image attachment and viewing.
- Odometer display and trip controls.
- Native Android foreground location service with persistent notification actions:
  Start, Pause, Stop. GPS points with poor accuracy are ignored; movement is
  distance-filtered to reduce stationary GPS drift. Trip distance is added to
  the odometer when Stop is used.
- Existing reminder scheduling and the original app sections are retained.

IMPORTANT TEST NOTES:
- Allow location and notification permissions when Android asks.
- Start trip only from the in-app controls for the first start. The ongoing
  Android notification then provides Start / Pause / Stop actions.
- GPS distance is an estimate and should be checked against the car odometer.
- Location tracking depends on Android permissions, GPS reception, and battery
  restrictions. Test in a safe situation; do not operate the phone while driving.
- Local app data is stored on this device. Back up important data separately.
- Dates use the Android date input and are displayed using the Persian locale.
